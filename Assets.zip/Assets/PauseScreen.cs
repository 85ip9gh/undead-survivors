using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseScreen : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        hidePause();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void hidePause()
    {
        this.gameObject.SetActive(false);
        unpause();
    }

    public void showPause()
    {
        this.gameObject.SetActive(true);
        pause();
    }

    public void pause()
    {
        Time.timeScale = 0f;
    }

    public void unpause()
    {
        Time.timeScale = 1.0f;
    }

    public void quit()
    {
        UnityEditor.EditorApplication.isPlaying = false;
        Application.Quit();
    }
}
