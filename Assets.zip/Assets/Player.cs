using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class Player : MonoBehaviour
{
    private float speed = 5f;
    private Rigidbody2D rb;
    private Vector2 direction;

    private Animator animator;
    private SpriteRenderer spriteRenderer;

    public PauseScreen script;
    private int health;
    private float immunity;
    private float attackCooldown;
    private const float ATTACK_COOLDOWN = 1.1f;

    private bool attacked;
    public BasicAttack attackScript;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();

        health = 5;
        immunity = 0;
        attackCooldown = 0;
        attacked = false;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        immunity -= Time.fixedDeltaTime;
        attackCooldown -= Time.fixedDeltaTime;

        float inputX = Input.GetAxis("Horizontal");
        float inputY = Input.GetAxis("Vertical");

        direction = new Vector2(inputX, inputY);

        if (Mathf.Abs(direction.x) == 1 || Mathf.Abs(direction.y) == 1)
        {
            direction.Normalize();
        }

        if (Input.GetKey(KeyCode.Space) && attackCooldown < 0 || attackCooldown >= ATTACK_COOLDOWN - 0.533f)
        {
            if (attacked == false)
            {
                attacked = true;
                attackCooldown = ATTACK_COOLDOWN;
                attackScript.attack();
            }
            animator.PlayInFixedTime("Attack");
        }
        else
        {
            attacked = false;
            if (inputX == 0 && inputY == 0)
            {
                animator.PlayInFixedTime("Player");
            }
            else
            {
                animator.PlayInFixedTime("Moving");
            }
        }

        if (inputX > 0)
        {
            spriteRenderer.flipX = false;
        }
        if (inputX < 0)
        {
            spriteRenderer.flipX = true;
        }

        rb.MovePosition(rb.position + (direction * Time.fixedDeltaTime * speed));

        if (Input.GetKey(KeyCode.Escape))
        {
            script.showPause();
        }
    }

    public void OnHit()
    {
        if (health > 0 && immunity < 0)
        {
            health--;
            immunity = 2f;
        }

        if (health == 0)
        {
            Debug.Log("L");

            script.pause();
        }
    }
}
