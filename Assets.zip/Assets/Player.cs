using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private float speed = 5f;
    private Rigidbody2D rb;
    private Vector2 direction;

    private Animator animator;
    private SpriteRenderer spriteRenderer;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float inputX = Input.GetAxis("Horizontal");
        float inputY = Input.GetAxis("Vertical");

        direction = new Vector2(inputX, inputY);

        if (Mathf.Abs(direction.x) == 1 || Mathf.Abs(direction.y) == 1)
        {
            direction.Normalize();
        }

        if (inputX == 0 && inputY == 0)
        {
            animator.Play("Wait");
        } else
        {
            animator.Play("Pplayer");
        }

        if (inputX > 0)
        {
            spriteRenderer.flipX = false;
        }
        if (inputX < 0)
        {
            spriteRenderer.flipX = true;
        }

        rb.MovePosition(rb.position + (direction * Time.fixedDeltaTime * speed));
    }
}
