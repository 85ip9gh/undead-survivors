Background Sprites: https://snowhex.itch.io/dungeon-gathering
Gem Sprite: https://clockworkraven.itch.io/rpg-icon-pack-jewels-and-gems
Player Sprite: https://penzilla.itch.io/hooded-protagonist

For this lab, half of it was already done practically. I had previously experimented and coded player movement (with diagonal normalization) and wall collision (using a composite collider) for the final project, so all that took was some repurposing and referencing my old work. In addition, creating the collectable gems was quite easy, as all I did was create one with a trigger collider, attach a script that calls it to destroy itself when triggered, then copy and paste it before spreading around the copies.

The main bulk of the work for this lab came from a totally unnecessary detail, bu I wanted to add it anyways. Essentially, I added animation to the player so that when they move, it players a moving animation and when they stand still, they play an idle animation. Additionally, if the player moves left, they face left and vice versa.